package my.learning.springAzure;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAzureApplicationTests {

	@Test
	void contextLoads() {
	}

}
